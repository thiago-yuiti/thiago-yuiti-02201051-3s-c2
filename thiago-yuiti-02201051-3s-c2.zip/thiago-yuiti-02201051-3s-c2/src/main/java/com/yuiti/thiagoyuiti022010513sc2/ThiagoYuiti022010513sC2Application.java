package com.yuiti.thiagoyuiti022010513sc2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ThiagoYuiti022010513sC2Application {

	public static void main(String[] args) {
		SpringApplication.run(ThiagoYuiti022010513sC2Application.class, args);
	}

}
