package com.yuiti.thiagoyuiti022010513sc2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ThiagoYuiti022010513sC2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
